# LatestBrain-TV
This repository contains latest code of brain-tv product which is compatible with CUDA 12.1 and PyTorch 2.1.0 stable version.
